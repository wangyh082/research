function r=randNo(a,b);
    r = rand(1);
    r = a+r*(b-a);
%%%    y=r;
end